package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.data.AppDatabase
import com.example.data.DataRepository
import com.example.data.SettingsRepository
import com.example.effects.EffectOverlay
import com.example.effects.FloatingFxControl
import com.example.ui.screens.ChessScreen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * Owns two overlay windows:
 * 1) a full-screen click-through renderer;
 * 2) a tiny touchable controller that toggles FX instantly.
 */
class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        const val ACTION_STOP_FX = "com.example.nexusfx.STOP_FX"
        const val ACTION_OPEN_CHESS = "com.example.nexusfx.OPEN_CHESS"
        const val ACTION_CLOSE_CHESS = "com.example.nexusfx.CLOSE_CHESS"
    }

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main.immediate + job)
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    private lateinit var windowManager: WindowManager
    private lateinit var repository: DataRepository
    private lateinit var settings: SettingsRepository

    private var effectView: ComposeView? = null
    private var controlView: ComposeView? = null
    private var chessView: ComposeView? = null

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    override fun onCreate() {
        super.onCreate()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val database = AppDatabase.getDatabase(applicationContext)
        repository = DataRepository(database.nexusDao())
        settings = SettingsRepository(applicationContext)

        startForeground(1, createNotification())
        setupEffectOverlay()
        setupFloatingControl()
    }

    private fun createNotification(): Notification {
        val channelId = "nexus_fx_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "NEXUS FX Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP_FX
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stopPendingIntent = PendingIntent.getService(this, 10, stopIntent, flags)

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("NEXUS FX Engine")
            .setContentText("Floating visual effects are active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "STOP FX", stopPendingIntent)
            .build()
    }

    private fun attachComposeView(view: ComposeView) {
        view.setViewTreeLifecycleOwner(this)
        view.setViewTreeSavedStateRegistryOwner(this)
    }

    private fun setupEffectOverlay() {
        val view = ComposeView(this)
        attachComposeView(view)
        view.setContent { EffectOverlay(repository, settings) }
        effectView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Android 12+ blocks pass-through touches from an opaque
            // TYPE_APPLICATION_OVERLAY even when FLAG_NOT_TOUCHABLE is set.
            // Keep the overlay safely below the maximum obscuring opacity so
            // touches continue to reach the app underneath.
            alpha = 0.75f
        }

        windowManager.addView(view, params)
    }

    private fun setupFloatingControl() {
        val view = ComposeView(this)
        attachComposeView(view)
        view.setContent { FloatingFxControl(settings) }
        controlView = view

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18
            y = 72
        }

        windowManager.addView(view, params)

        // Hide/show the controller from the in-app setting without touching the
        // full-screen renderer.
        scope.launch {
            settings.isFloatingControlEnabled.collect { enabled ->
                view.post {
                    if (enabled) {
                        if (view.parent == null) {
                            runCatching { windowManager.addView(view, params) }
                        }
                        view.visibility = android.view.View.VISIBLE
                    } else {
                        view.visibility = android.view.View.GONE
                    }
                }
            }
        }
    }

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_FX -> { stopSelf(); return START_NOT_STICKY }
            ACTION_OPEN_CHESS -> { showChessOverlay() }
            ACTION_CLOSE_CHESS -> { hideChessOverlay() }
        }
        return START_STICKY
    }


    private fun showChessOverlay() {
        if (chessView?.parent != null) return
        val view = ComposeView(this)
        attachComposeView(view)
        view.setContent { ChessScreen(onBack = { hideChessOverlay() }) }
        chessView = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager.addView(view, params)
    }

    private fun hideChessOverlay() {
        runCatching { chessView?.let { if (it.parent != null) windowManager.removeViewImmediate(it) } }
        chessView = null
    }
    override fun onDestroy() {
        runCatching { effectView?.let { windowManager.removeViewImmediate(it) } }
        runCatching { controlView?.let { windowManager.removeViewImmediate(it) } }
        runCatching { chessView?.let { windowManager.removeViewImmediate(it) } }
        effectView = null
        controlView = null
        chessView = null
        job.cancel()

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
