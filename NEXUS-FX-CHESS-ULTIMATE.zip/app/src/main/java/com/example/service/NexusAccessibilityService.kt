package com.example.service

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class NexusAccessibilityService : AccessibilityService() {

    companion object {
        private val _currentPackage = MutableStateFlow<String?>(null)
        val currentPackage: StateFlow<String?> = _currentPackage
        
        // Emits timestamp of click/touch to trigger touch FX
        private val _touchEvents = MutableStateFlow<TouchEvent?>(null)
        val touchEvents: StateFlow<TouchEvent?> = _touchEvents
    }

    data class TouchEvent(val timestamp: Long, val x: Float, val y: Float)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            if (packageName != null && packageName != "com.example") {
                _currentPackage.value = packageName
            }
        } else if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val node = event.source
            if (node != null) {
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                val cx = rect.exactCenterX()
                val cy = rect.exactCenterY()
                _touchEvents.value = TouchEvent(System.currentTimeMillis(), cx, cy)
                node.recycle()
            }
        }
    }

    override fun onInterrupt() {
        Log.d("NexusAccessibility", "Service Interrupted")
    }
}
