package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.service.OverlayService
import com.example.ui.NexusViewModel
import com.example.ui.screens.AppSelectorScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: NexusViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ensureOverlayPermissionOrStart()

        val openChess = intent?.getBooleanExtra("OPEN_CHESS_PAGE", false) == true
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(navController = navController, startDestination = if (openChess) "chess" else "dashboard") {
                        composable("dashboard") {
                            DashboardScreen(
                                viewModel = viewModel,
                                onNavigateToApps = { navController.navigate("apps") },
                                onNavigateToProfiles = { navController.navigate("profiles") },
                                onNavigateToChess = { navController.navigate("chess") }
                            )
                        }
                        composable("apps") {
                            AppSelectorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                        composable("chess") {
                            com.example.ui.screens.ChessScreen(onBack = { navController.popBackStack() })
                        }
                        composable("profiles") {
                            com.example.ui.screens.ProfileEditorScreen(
                                viewModel = viewModel,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Returning from Android's "Display over other apps" page must actually
        // start the renderer; previously this could leave the app waiting forever.
        ensureOverlayPermissionOrStart(openSettingsIfMissing = false)
    }

    private fun ensureOverlayPermissionOrStart(openSettingsIfMissing: Boolean = true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            if (openSettingsIfMissing) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
            return
        }

        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
