package com.example.data

import com.example.data.model.AppSelection
import com.example.data.model.Profile
import kotlinx.coroutines.flow.Flow

class DataRepository(private val dao: NexusDao) {
    val allProfiles: Flow<List<Profile>> = dao.getAllProfiles()
    val allAppSelections: Flow<List<AppSelection>> = dao.getAllAppSelections()

    suspend fun insertProfile(profile: Profile): Long = dao.insertProfile(profile)
    suspend fun deleteProfile(id: Int) = dao.deleteProfile(id)
    fun getProfileById(id: Int): Flow<Profile?> = dao.getProfileById(id)
    suspend fun getAnyProfile(): Profile? = dao.getAnyProfile()

    suspend fun insertAppSelection(appSelection: AppSelection) = dao.insertAppSelection(appSelection)
    suspend fun deleteAppSelection(packageName: String) = dao.deleteAppSelection(packageName)
    fun getAppSelection(packageName: String): Flow<AppSelection?> = dao.getAppSelection(packageName)
}
