package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class Profile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val effectType: String = "Matrix Rain", // "Matrix Rain", "Cyber Grid", "Scanlines", "Particles", "Digital Glitch", "Radar", "Energy Pulse"
    val primaryColor: Long = 0xFF00FFFF, // Electric Cyan
    val opacity: Float = 0.35f,
    val clickSound: String = "Cyber Click",
    val speed: Float = 1.0f,
    val density: Float = 1.0f
)
