package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.AppSelection
import com.example.data.model.Profile
import kotlinx.coroutines.flow.Flow

@Dao
interface NexusDao {
    @Query("SELECT * FROM profiles")
    fun getAllProfiles(): Flow<List<Profile>>

    @Query("SELECT * FROM profiles WHERE id = :id")
    fun getProfileById(id: Int): Flow<Profile?>

    @Query("SELECT * FROM profiles LIMIT 1")
    suspend fun getAnyProfile(): Profile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: Profile): Long

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteProfile(id: Int)

    @Query("SELECT * FROM app_selections")
    fun getAllAppSelections(): Flow<List<AppSelection>>
    
    @Query("SELECT * FROM app_selections WHERE packageName = :packageName")
    fun getAppSelection(packageName: String): Flow<AppSelection?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppSelection(appSelection: AppSelection)

    @Query("DELETE FROM app_selections WHERE packageName = :packageName")
    suspend fun deleteAppSelection(packageName: String)
}
