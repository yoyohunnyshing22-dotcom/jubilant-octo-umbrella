package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {
    private val IS_GLOBAL_FX_ENABLED = booleanPreferencesKey("is_global_fx_enabled")
    private val IS_SOUND_ENABLED = booleanPreferencesKey("is_sound_enabled")
    private val IS_BATTERY_SAVER = booleanPreferencesKey("is_battery_saver")
    private val IS_FLOATING_CONTROL_ENABLED = booleanPreferencesKey("is_floating_control_enabled")

    val isGlobalFxEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_GLOBAL_FX_ENABLED] ?: true }

    val isSoundEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_SOUND_ENABLED] ?: true }

    val isBatterySaver: Flow<Boolean> = context.dataStore.data
        .map { it[IS_BATTERY_SAVER] ?: false }

    /** Whether the always-on floating FX controller should be visible. */
    val isFloatingControlEnabled: Flow<Boolean> = context.dataStore.data
        .map { it[IS_FLOATING_CONTROL_ENABLED] ?: true }

    suspend fun setGlobalFxEnabled(enabled: Boolean) {
        context.dataStore.edit { it[IS_GLOBAL_FX_ENABLED] = enabled }
    }

    suspend fun setSoundEnabled(enabled: Boolean) {
        context.dataStore.edit { it[IS_SOUND_ENABLED] = enabled }
    }

    suspend fun setBatterySaver(enabled: Boolean) {
        context.dataStore.edit { it[IS_BATTERY_SAVER] = enabled }
    }

    suspend fun setFloatingControlEnabled(enabled: Boolean) {
        context.dataStore.edit { it[IS_FLOATING_CONTROL_ENABLED] = enabled }
    }
}
