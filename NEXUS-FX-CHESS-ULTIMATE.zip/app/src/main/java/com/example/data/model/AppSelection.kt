package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_selections")
data class AppSelection(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isEnabled: Boolean = true,
    val profileId: Int // Foreign key to profiles, but for simplicity kept loose
)
