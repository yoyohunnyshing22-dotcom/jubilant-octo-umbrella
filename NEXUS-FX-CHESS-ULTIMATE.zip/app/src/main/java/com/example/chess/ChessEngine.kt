package com.example.chess

import kotlin.math.abs

/** Compact, fully offline chess rules + alpha-beta engine. No network or API required. */
data class Move(val from: Int, val to: Int, val promotion: Char = ' ', val castle: Boolean = false, val enPassant: Boolean = false)

data class Position(
    val board: CharArray = initialBoard(),
    val whiteToMove: Boolean = true,
    val whiteCastleK: Boolean = true,
    val whiteCastleQ: Boolean = true,
    val blackCastleK: Boolean = true,
    val blackCastleQ: Boolean = true,
    val enPassant: Int = -1,
    val halfmove: Int = 0
) {
    fun copyBoard() = board.copyOf()

    companion object {
        fun initial(): Position = Position()
        private fun initialBoard(): CharArray = charArrayOf(
            'r','n','b','q','k','b','n','r',
            'p','p','p','p','p','p','p','p',
            *CharArray(32) { ' ' },
            'P','P','P','P','P','P','P','P',
            'R','N','B','Q','K','B','N','R'
        )
    }
}

object ChessEngine {
    private val values = mapOf('P' to 100,'N' to 320,'B' to 330,'R' to 500,'Q' to 900,'K' to 20000)
    private val killer = HashMap<Int, Move>()

    fun legalMoves(p: Position): List<Move> {
        val pseudo = pseudoMoves(p)
        return pseudo.filter { !isInCheck(apply(p, it), !p.whiteToMove) }
    }

    fun isInCheck(p: Position, white: Boolean): Boolean {
        val king = p.board.indexOf(if (white) 'K' else 'k')
        if (king < 0) return true
        return attacked(p.board, king, !white)
    }

    fun apply(p: Position, m: Move): Position {
        val b = p.copyBoard()
        val piece = b[m.from]
        val captured = b[m.to]
        b[m.from] = ' '
        if (m.enPassant) b[m.to + if (piece == 'P') 8 else -8] = ' '
        b[m.to] = if (m.promotion != ' ') m.promotion else piece
        if (m.castle) {
            when (m.to) {
                62 -> { b[61] = 'R'; b[63] = ' ' }
                58 -> { b[59] = 'R'; b[56] = ' ' }
                6 -> { b[5] = 'r'; b[7] = ' ' }
                2 -> { b[3] = 'r'; b[0] = ' ' }
            }
        }
        var wk = p.whiteCastleK; var wq = p.whiteCastleQ
        var bk = p.blackCastleK; var bq = p.blackCastleQ
        when (m.from) { 60 -> { wk = false; wq = false }; 56 -> wq = false; 63 -> wk = false; 4 -> { bk = false; bq = false }; 0 -> bq = false; 7 -> bk = false }
        when (m.to) { 56 -> wq = false; 63 -> wk = false; 0 -> bq = false; 7 -> bk = false }
        val ep = if (piece.uppercaseChar() == 'P' && abs(m.to - m.from) == 16) (m.from + m.to) / 2 else -1
        return Position(b, !p.whiteToMove, wk, wq, bk, bq, ep, if (piece.uppercaseChar() == 'P' || captured != ' ') 0 else p.halfmove + 1)
    }

    fun bestMove(position: Position, maxDepth: Int = 4): Move? {
        val moves = legalMoves(position)
        if (moves.isEmpty()) return null
        var best = moves.first()
        var bestScore = Int.MIN_VALUE + 1
        val table = HashMap<Long, Pair<Int, Int>>()
        for (depth in 1..maxDepth) {
            var localBest = best
            var localScore = Int.MIN_VALUE + 1
            val ordered = moves.sortedByDescending { moveOrder(position, it) }
            for (m in ordered) {
                val score = -search(apply(position, m), depth - 1, Int.MIN_VALUE + 1, Int.MAX_VALUE - 1, table, 1)
                if (score > localScore) { localScore = score; localBest = m }
            }
            best = localBest; bestScore = localScore
            if (bestScore > 19000) break
        }
        return best
    }

    private fun search(p: Position, depth: Int, alphaIn: Int, beta: Int, table: MutableMap<Long, Pair<Int, Int>>, ply: Int): Int {
        val moves = legalMoves(p)
        if (moves.isEmpty()) {
            return if (isInCheck(p, p.whiteToMove)) -20000 + ply else 0
        }
        if (depth <= 0) return evaluate(p)
        var alpha = alphaIn
        var best = Int.MIN_VALUE + 1
        for (m in moves.sortedByDescending { moveOrder(p, it) }) {
            val score = -search(apply(p, m), depth - 1, -beta, -alpha, table, ply + 1)
            if (score > best) best = score
            if (score > alpha) alpha = score
            if (alpha >= beta) { killer[depth] = m; break }
        }
        return best
    }

    private fun evaluate(p: Position): Int {
        var score = 0
        for (i in p.board.indices) {
            val c = p.board[i]
            val v = values[c.uppercaseChar()] ?: 0
            val r = i / 8; val f = i % 8
            val center = 4 - abs(3.5 - f).toInt() + 4 - abs(3.5 - r).toInt()
            val bonus = when (c.uppercaseChar()) {
                'P' -> if (r in 2..5) center * 2 else 0
                'N','B' -> center * 5
                'Q' -> center * 2
                'K' -> if (p.halfmove < 20) -center * 2 else center * 3
                else -> 0
            }
            score += if (c.isUpperCase()) v + bonus else -(v + bonus)
        }
        val mobility = legalMovesNoRecursion(p).size
        score += if (p.whiteToMove) mobility else -mobility
        return if (p.whiteToMove) score else -score
    }

    private fun legalMovesNoRecursion(p: Position): List<Move> = pseudoMoves(p).filter { !isInCheck(apply(p, it), !p.whiteToMove) }

    private fun moveOrder(p: Position, m: Move): Int {
        val capture = values[p.board[m.to].uppercaseChar()] ?: 0
        val mover = values[p.board[m.from].uppercaseChar()] ?: 0
        return capture * 10 - mover + if (m.promotion != ' ') 800 else 0
    }

    private fun pseudoMoves(p: Position): List<Move> {
        val out = ArrayList<Move>(64)
        for (i in 0..63) {
            val c = p.board[i]; if (c == ' ' || c.isUpperCase() != p.whiteToMove) continue
            val f = i % 8; val r = i / 8
            when (c.uppercaseChar()) {
                'P' -> pawn(p, i, f, r, out)
                'N' -> for ((df,dr) in knightDirs) addIf(p,i,f+df,r+dr,out)
                'B' -> slide(p,i,f,r,out,bishopDirs)
                'R' -> slide(p,i,f,r,out,rookDirs)
                'Q' -> slide(p,i,f,r,out,bishopDirs + rookDirs)
                'K' -> { for ((df,dr) in kingDirs) addIf(p,i,f+df,r+dr,out); castle(p,i,out) }
            }
        }
        return out
    }

    private fun pawn(p: Position, i: Int, f: Int, r: Int, out: MutableList<Move>) {
        val white = p.whiteToMove; val dir = if (white) -1 else 1; val start = if (white) 6 else 1; val promo = if (white) 0 else 7
        val oneR = r + dir
        if (oneR in 0..7 && p.board[oneR*8+f] == ' ') {
            addPawn(i, oneR*8+f, white, promo, out)
            if (r == start && p.board[(r+2*dir)*8+f] == ' ') out.add(Move(i,(r+2*dir)*8+f))
        }
        for (df in intArrayOf(-1,1)) {
            val nf=f+df; if (nf !in 0..7 || oneR !in 0..7) continue
            val to=oneR*8+nf; val target=p.board[to]
            if (target != ' ' && target.isUpperCase()!=white) addPawn(i,to,white,promo,out)
            else if (to == p.enPassant) out.add(Move(i,to,enPassant=true))
        }
    }
    private fun addPawn(from:Int,to:Int,white:Boolean,promoRank:Int,out:MutableList<Move>) {
        if (to/8==promoRank) for (x in if(white) "QRBN" else "qrbn") out.add(Move(from,to,x)) else out.add(Move(from,to))
    }
    private fun addIf(p:Position, f:Int, file:Int, rank:Int, out:MutableList<Move>) {
        if (file !in 0..7 || rank !in 0..7) return
        val to=rank*8+file; if (p.board[to]==' ' || p.board[to].isUpperCase()!=p.whiteToMove) out.add(Move(f,to))
    }
    private fun slide(p:Position,i:Int,f:Int,r:Int,out:MutableList<Move>,dirs:Array<Pair<Int,Int>>) {
        for ((df,dr) in dirs) { var nf=f+df; var nr=r+dr; while(nf in 0..7 && nr in 0..7) { val to=nr*8+nf; val t=p.board[to]; if(t==' ') out.add(Move(i,to)) else { if(t.isUpperCase()!=p.whiteToMove) out.add(Move(i,to)); break }; nf+=df; nr+=dr } }
    }
    private fun castle(p:Position,i:Int,out:MutableList<Move>) {
        if (p.whiteToMove && i==60 && !isInCheck(p,true)) {
            if(p.whiteCastleK && p.board[61]==' '&&p.board[62]==' '&&!attacked(p.board,61,false)&&!attacked(p.board,62,false)) out.add(Move(60,62,castle=true))
            if(p.whiteCastleQ && p.board[59]==' '&&p.board[58]==' '&&p.board[57]==' '&&!attacked(p.board,59,false)&&!attacked(p.board,58,false)) out.add(Move(60,58,castle=true))
        } else if (!p.whiteToMove && i==4 && !isInCheck(p,false)) {
            if(p.blackCastleK && p.board[5]==' '&&p.board[6]==' '&&!attacked(p.board,5,true)&&!attacked(p.board,6,true)) out.add(Move(4,6,castle=true))
            if(p.blackCastleQ && p.board[3]==' '&&p.board[2]==' '&&p.board[1]==' '&&!attacked(p.board,3,true)&&!attacked(p.board,2,true)) out.add(Move(4,2,castle=true))
        }
    }
    private fun attacked(b:CharArray,s:Int,byWhite:Boolean):Boolean {
        val f=s%8; val r=s/8
        val pr=if(byWhite) r+1 else r-1
        if(pr in 0..7) for(df in intArrayOf(-1,1)){val ff=f+df;if(ff in 0..7 && b[pr*8+ff]==if(byWhite)'P' else 'p')return true}
        for((df,dr) in knightDirs){val ff=f+df;val rr=r+dr;if(ff in 0..7&&rr in 0..7&&b[rr*8+ff]==if(byWhite)'N' else 'n')return true}
        for((df,dr) in bishopDirs){var ff=f+df;var rr=r+dr;while(ff in 0..7&&rr in 0..7){val c=b[rr*8+ff];if(c!=' '){if(c==if(byWhite)'B' else 'b'||c==if(byWhite)'Q' else 'q')return true;break};ff+=df;rr+=dr}}
        for((df,dr) in rookDirs){var ff=f+df;var rr=r+dr;while(ff in 0..7&&rr in 0..7){val c=b[rr*8+ff];if(c!=' '){if(c==if(byWhite)'R' else 'r'||c==if(byWhite)'Q' else 'q')return true;break};ff+=df;rr+=dr}}
        for((df,dr) in kingDirs){val ff=f+df;val rr=r+dr;if(ff in 0..7&&rr in 0..7&&b[rr*8+ff]==if(byWhite)'K' else 'k')return true}
        return false
    }
    private val knightDirs=arrayOf(1 to 2,2 to 1,2 to -1,1 to -2,-1 to -2,-2 to -1,-2 to 1,-1 to 2)
    private val bishopDirs=arrayOf(1 to 1,1 to -1,-1 to 1,-1 to -1)
    private val rookDirs=arrayOf(1 to 0,-1 to 0,0 to 1,0 to -1)
    private val kingDirs=bishopDirs+rookDirs
}
