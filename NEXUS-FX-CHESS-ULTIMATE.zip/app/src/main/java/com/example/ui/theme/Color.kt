package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val AppBackground = Color(0xFF050505)
val SurfaceCard = Color(0xFF121212)
val SurfaceCardHeader = Color(0xFF1A1A1A)
val SurfaceCardVariant = Color(0xFF151515)
val BorderColor = Color(0xFF222222)
val BorderLight = Color(0xFF333333)

val CyanAccent = Color(0xFF00E5FF)
val RedAccent = Color(0xFFFF0000)
val GreenAccent = Color(0xFF4ADE80) // Tailwind green-400

val TextPrimary = Color(0xFFE0E0E0)
val TextWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFF9CA3AF) // gray-400
val TextMuted = Color(0xFF6B7280) // gray-500

