package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.data.model.Profile
import com.example.effects.CyberGridEffect
import com.example.effects.MatrixRainEffect
import com.example.effects.ParticlesEffect
import com.example.effects.ScanlinesEffect
import com.example.ui.NexusViewModel
import kotlinx.coroutines.launch

@Composable
fun ProfileEditorScreen(viewModel: NexusViewModel, onBack: () -> Unit) {
    val profiles by viewModel.profiles.collectAsState()
    var selectedProfile by remember { mutableStateOf<Profile?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold { padding ->
        if (selectedProfile == null) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { Text("Effect Profiles", style = MaterialTheme.typography.headlineMedium) }
                items(profiles) { profile ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectedProfile = profile },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(text = profile.name, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        } else {
            selectedProfile?.let { profile ->
                Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                    // Preview Area
                    Box(modifier = Modifier.fillMaxWidth().weight(1f).background(Color.Black)) {
                        when (profile.effectType) {
                            "Matrix Rain" -> MatrixRainEffect(profile)
                            "Cyber Grid" -> CyberGridEffect(profile)
                            "Scanlines" -> ScanlinesEffect(profile)
                            "Particles" -> ParticlesEffect(profile)
                            else -> MatrixRainEffect(profile)
                        }
                    }
                    
                    // Controls
                    Column(
                        modifier = Modifier.fillMaxWidth().weight(1f).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(profile.name, style = MaterialTheme.typography.titleLarge)
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val colors = listOf(0xFF00E5FF, 0xFF00FF41, 0xFFFF003C, 0xFF9D00FF, 0xFFFFFFFF)
                            colors.forEach { color ->
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color(color))
                                        .clickable {
                                            selectedProfile = profile.copy(primaryColor = color)
                                        }
                                )
                            }
                        }

                        Text("Opacity")
                        Slider(
                            value = profile.opacity,
                            onValueChange = { selectedProfile = profile.copy(opacity = it) }
                        )

                        Text("Speed")
                        Slider(
                            value = profile.speed,
                            onValueChange = { selectedProfile = profile.copy(speed = it) },
                            valueRange = 0.1f..3f
                        )

                        Text("Density")
                        Slider(
                            value = profile.density,
                            onValueChange = { selectedProfile = profile.copy(density = it) },
                            valueRange = 0.1f..3f
                        )
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Button(onClick = { selectedProfile = null }) { Text("Cancel") }
                            Button(onClick = {
                                scope.launch {
                                    viewModel.repository.insertProfile(profile)
                                    selectedProfile = null
                                }
                            }) { Text("Save") }
                        }
                    }
                }
            }
        }
    }
}
