package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.chess.ChessEngine
import com.example.chess.Move
import com.example.chess.Position
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ChessScreen(
    onBack: (() -> Unit)? = null,
) {
    var position by remember { mutableStateOf(Position.initial()) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var status by remember { mutableStateOf("WHITE // READY") }
    var botThinking by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(ChessMode.BOT) }
    var botDepth by remember { mutableIntStateOf(4) }
    val scope = rememberCoroutineScope()
    val legal = remember(position) { ChessEngine.legalMoves(position) }
    val selectedMoves = remember(position, selected) { selected?.let { s -> legal.filter { it.from == s }.map { it.to }.toSet() } ?: emptySet() }

    fun reset() { position = Position.initial(); selected = null; status = "WHITE // READY"; botThinking = false }
    fun makeMove(move: Move) {
        position = ChessEngine.apply(position, move); selected = null
        val nextMoves = ChessEngine.legalMoves(position)
        status = when {
            nextMoves.isEmpty() && ChessEngine.isInCheck(position, position.whiteToMove) -> if (position.whiteToMove) "BLACK // CHECKMATE" else "WHITE // CHECKMATE"
            nextMoves.isEmpty() -> "DRAW // STALEMATE"
            ChessEngine.isInCheck(position, position.whiteToMove) -> if(position.whiteToMove) "WHITE // CHECK" else "BLACK // CHECK"
            else -> if(position.whiteToMove) "WHITE // MOVE" else "BLACK // MOVE"
        }
        if (mode == ChessMode.BOT && !position.whiteToMove && nextMoves.isNotEmpty()) {
            botThinking = true
            scope.launch {
                val best = withContext(Dispatchers.Default) { ChessEngine.bestMove(position, botDepth) }
                if (best != null) makeMove(best)
                botThinking = false
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF10222B), Color(0xFF03070A))))) {
        ChessCyberBackdrop(pulse)
        val transition = rememberInfiniteTransition(label = "chess")
        val pulse by transition.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1400, easing=FastOutSlowInEasing), RepeatMode.Reverse), label="pulse")
        Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("NEXUS // CHESS", color=Color(0xFF00E5FF), fontSize=20.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick={showSettings=true}) { Text("SETTINGS", color=Color(0xFF00E5FF)) }
                    if(onBack!=null) TextButton(onClick=onBack) { Text("BACK", color=Color.White) }
                }
            }
            Text(if(botThinking) "NEURAL ENGINE // CALCULATING" else status, color=Color.White.copy(alpha=pulse), fontSize=12.sp)
            Spacer(Modifier.height(12.dp))
            ChessBoard(position, selected, selectedMoves, botThinking) { index ->
                if(botThinking || (mode==ChessMode.BOT && !position.whiteToMove)) return@ChessBoard
                val s=selected
                if(s==null) { if(position.board[index]!=' ' && position.board[index].isUpperCase()==position.whiteToMove) selected=index }
                else {
                    val move=legal.firstOrNull{it.from==s&&it.to==index}
                    if(move!=null) makeMove(move) else if(position.board[index]!=' '&&position.board[index].isUpperCase()==position.whiteToMove) selected=index else selected=null
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                Button(onClick={reset()}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF07141A))) { Text("NEW GAME") }
                Button(onClick={showSettings=true}, modifier=Modifier.weight(1f), colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF07141A))) { Text(if(mode==ChessMode.BOT) "BOT MODE" else "2 PLAYER") }
            }
            Spacer(Modifier.height(8.dp))
            Text("OFFLINE ENGINE • NO NETWORK • NO API", color=Color(0xFF5B7D86), fontSize=10.sp)
        }
        if(showSettings) ChessSettingsDialog(mode, botDepth, { mode=it }, { botDepth=it }, {showSettings=false})
    }
}

@Composable
private fun ChessCyberBackdrop(pulse: Float) {
    val transition = rememberInfiniteTransition(label = "chess_backdrop")
    val sweep by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing=FastOutSlowInEasing), RepeatMode.Restart), label="sweep")
    Canvas(Modifier.fillMaxSize().alpha(.62f)) {
        val cx=size.width/2f; val cy=size.height*.47f
        for (ring in 1..4) drawCircle(Color(0xFF00E5FF).copy(alpha=.035f), ring*size.minDimension*.14f, Offset(cx,cy), style=Stroke(width=1f))
        val y=sweep*size.height
        drawRect(Color(0xFF00E5FF).copy(alpha=.055f), Offset(0f,y), Size(size.width,2f))
        drawCircle(Color(0xFF00E5FF).copy(alpha=.08f*pulse), size.minDimension*.08f, Offset(cx,cy), style=Stroke(width=2f))
    }
}

@Composable private fun ChessBoard(p:Position, selected:Int?, targets:Set<Int>, thinking:Boolean, onCell:(Int)->Unit) {
    val boardModifier=Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp)).border(1.dp,Color(0xFF00E5FF).copy(.65f),RoundedCornerShape(14.dp))
    Canvas(boardModifier) {
        val s=size.minDimension/8f
        for(i in 0..63){ val x=(i%8)*s; val y=(i/8)*s; val light=((i/8+i%8)%2==0); drawRect(if(light)Color(0xFF12323A) else Color(0xFF061318),androidx.compose.ui.geometry.Offset(x,y),androidx.compose.ui.geometry.Size(s,s)); if(i==selected) drawRect(Color(0xFF00E5FF).copy(.38f),androidx.compose.ui.geometry.Offset(x,y),androidx.compose.ui.geometry.Size(s,s)); if(i in targets) drawCircle(Color(0xFF00E5FF).copy(.75f),s*.13f,androidx.compose.ui.geometry.Offset(x+s/2,y+s/2)) }
    }
    // A second transparent grid of buttons keeps the board reliably touchable.
    Column(Modifier.fillMaxWidth().aspectRatio(1f).offset(y=(-sizeOfBoardOverlapDp()))) { repeat(8){r->Row(Modifier.weight(1f)){repeat(8){f->Box(Modifier.weight(1f).fillMaxHeight().clickable(enabled=!thinking){onCell(r*8+f)},contentAlignment=Alignment.Center){ Text(pieceGlyph(p.board[r*8+f]),fontSize=30.sp) }}}} }
}
private fun sizeOfBoardOverlapDp()=0.dp
private fun pieceGlyph(c:Char)=when(c){'K'->"♔";'Q'->"♕";'R'->"♖";'B'->"♗";'N'->"♘";'P'->"♙";'k'->"♚";'q'->"♛";'r'->"♜";'b'->"♝";'n'->"♞";'p'->"♟";else->""}

enum class ChessMode { BOT, TWO_PLAYER }

@Composable private fun ChessSettingsDialog(mode: ChessMode, depth: Int, onMode:(ChessMode)->Unit, onDepth:(Int)->Unit, onClose:()->Unit){
    AlertDialog(onDismissRequest=onClose,title={Text("CHESS // CORE SETTINGS")},text={Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("MODE",fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            FilterChip(mode==ChessMode.BOT,{onMode(ChessMode.BOT)},{label={Text("DARK BOT")}})
            FilterChip(mode==ChessMode.TWO_PLAYER,{onMode(ChessMode.TWO_PLAYER)},{label={Text("2 PLAYER")}})
        }
        if(mode==ChessMode.BOT){
            Text("BOT STRENGTH: DEPTH $depth")
            Slider(depth.toFloat(),{onDepth(it.toInt().coerceIn(2,5))},valueRange=2f..5f,steps=2)
            Text("Deeper = stronger, but slower.",fontSize=11.sp)
        }
    }},confirmButton={TextButton(onClick=onClose){Text("APPLY")}})
}
