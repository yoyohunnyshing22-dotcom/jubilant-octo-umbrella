package com.example.ui

import android.app.Application
import android.content.pm.PackageManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.DataRepository
import com.example.data.SettingsRepository
import com.example.data.model.AppSelection
import com.example.data.model.Profile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NexusViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = DataRepository(database.nexusDao())
    val settings = SettingsRepository(application)
    private val packageManager = application.packageManager

    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps

    val appSelections: StateFlow<List<AppSelection>> = repository.allAppSelections.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )
    
    val profiles: StateFlow<List<Profile>> = repository.allProfiles.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    init {
        loadInstalledApps()
        checkInitialProfiles()
    }

    private fun checkInitialProfiles() {
        viewModelScope.launch {
            if (repository.getAnyProfile() == null) {
                repository.insertProfile(Profile(name = "Matrix Pro", effectType = "Matrix Rain", primaryColor = 0xFF00FF00))
                repository.insertProfile(Profile(name = "Cyber Blue", effectType = "Cyber Grid", primaryColor = 0xFF00E5FF))
                repository.insertProfile(Profile(name = "Red Scanlines", effectType = "Scanlines", primaryColor = 0xFFFF0044))
            }
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            val intent = android.content.Intent(android.content.Intent.ACTION_MAIN, null)
            intent.addCategory(android.content.Intent.CATEGORY_LAUNCHER)
            val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            
            val appList = apps.map { resolveInfo ->
                AppInfo(
                    packageName = resolveInfo.activityInfo.packageName,
                    name = resolveInfo.loadLabel(packageManager).toString()
                )
            }.distinctBy { it.packageName }.sortedBy { it.name }
            
            _installedApps.value = appList
        }
    }

    fun toggleAppSelection(appInfo: AppInfo, isEnabled: Boolean, profileId: Int) {
        viewModelScope.launch {
            if (isEnabled) {
                repository.insertAppSelection(AppSelection(appInfo.packageName, appInfo.name, true, profileId))
            } else {
                repository.deleteAppSelection(appInfo.packageName)
            }
        }
    }
}

data class AppInfo(val packageName: String, val name: String)
