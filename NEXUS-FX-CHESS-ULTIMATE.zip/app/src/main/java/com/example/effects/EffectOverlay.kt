package com.example.effects

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.data.DataRepository
import com.example.data.SettingsRepository
import kotlinx.coroutines.flow.firstOrNull

/**
 * Full-screen, click-through visual layer.
 *
 * IMPORTANT: this renderer is intentionally NOT tied to the foreground package.
 * That means effects continue to work over every app without maintaining an
 * app allow-list or waiting for accessibility window-change events.
 */
@Composable
fun EffectOverlay(repository: DataRepository, settings: SettingsRepository) {
    val isGlobalEnabled by settings.isGlobalFxEnabled.collectAsState(initial = true)
    val profiles by repository.allProfiles.collectAsState(initial = emptyList())
    val activeProfile = profiles.firstOrNull() ?: com.example.data.model.Profile(
        name = "Matrix Pro",
        effectType = "Matrix Rain",
        primaryColor = 0xFF00FFFF,
        opacity = 0.22f,
        speed = 1.0f,
        density = 0.9f,
        clickSound = "Cyber Click"
    )

    AnimatedVisibility(
        visible = isGlobalEnabled,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        when (activeProfile.effectType) {
            "Cyber Grid" -> CyberGridEffect(activeProfile)
            "Scanlines" -> ScanlinesEffect(activeProfile)
            "Particles" -> ParticlesEffect(activeProfile)
            else -> MatrixRainEffect(activeProfile)
        }

        TouchFeedbackEffect(activeProfile)
    }
}
