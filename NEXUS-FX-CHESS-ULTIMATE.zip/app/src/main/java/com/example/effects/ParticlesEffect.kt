package com.example.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.data.model.Profile
import kotlin.random.Random

@Composable
fun ParticlesEffect(profile: Profile) {
    val particleColor = Color(profile.primaryColor).copy(alpha = profile.opacity)
    val speedFactor = profile.speed * 50f
    
    var time by remember { mutableStateOf(0L) }
    
    LaunchedEffect(Unit) {
        val startTime = System.nanoTime()
        while (true) {
            withFrameNanos { frameTime ->
                time = frameTime - startTime
            }
        }
    }

    val particles = remember { mutableListOf<Particle>() }
    var width = 0f
    var height = 0f

    Canvas(modifier = Modifier.fillMaxSize()) {
        if (width != size.width || height != size.height) {
            width = size.width
            height = size.height
            particles.clear()
            val numParticles = (60 * profile.density).toInt().coerceAtLeast(10)
            for (i in 0 until numParticles) {
                particles.add(Particle(
                    x = Random.nextFloat() * width,
                    y = Random.nextFloat() * height,
                    vx = (Random.nextFloat() - 0.5f) * speedFactor,
                    vy = (Random.nextFloat() - 0.5f) * speedFactor,
                    radius = Random.nextFloat() * 4f + 2f
                ))
            }
        }

        for (p in particles) {
            p.x += p.vx * 0.016f // 60fps step approx
            p.y += p.vy * 0.016f
            
            if (p.x < 0) p.x = width
            if (p.x > width) p.x = 0f
            if (p.y < 0) p.y = height
            if (p.y > height) p.y = 0f
            
            drawCircle(
                color = particleColor,
                radius = p.radius,
                center = Offset(p.x, p.y)
            )
        }
    }
}

private class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float, val radius: Float)
