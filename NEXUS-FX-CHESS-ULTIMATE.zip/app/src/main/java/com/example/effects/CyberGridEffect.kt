package com.example.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.data.model.Profile

@Composable
fun CyberGridEffect(profile: Profile) {
    val gridColor = Color(profile.primaryColor).copy(alpha = profile.opacity)
    val speed = profile.speed * 100f
    
    var time by remember { mutableStateOf(0L) }
    
    LaunchedEffect(Unit) {
        val startTime = System.nanoTime()
        while (true) {
            withFrameNanos { frameTime ->
                time = frameTime - startTime
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val dt = time / 1_000_000_000f
        val spacing = 100f / profile.density
        val offset = (dt * speed) % spacing
        
        // Vertical lines with slight perspective simulation
        val cx = size.width / 2
        val cy = size.height / 2
        
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 2f
            )
            x += spacing
        }
        
        var y = offset
        while (y < size.height) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 2f
            )
            y += spacing
        }
    }
}
