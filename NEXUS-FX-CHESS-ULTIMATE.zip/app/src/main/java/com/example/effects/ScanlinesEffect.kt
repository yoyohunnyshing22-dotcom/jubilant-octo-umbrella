package com.example.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.data.model.Profile

@Composable
fun ScanlinesEffect(profile: Profile) {
    val scanlineColor = Color(profile.primaryColor).copy(alpha = profile.opacity)
    val speed = profile.speed * 200f
    
    var time by remember { mutableStateOf(0L) }
    
    LaunchedEffect(Unit) {
        val startTime = System.nanoTime()
        while (true) {
            withFrameNanos { frameTime ->
                time = frameTime - startTime
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val dt = time / 1_000_000_000f
        val spacing = 10f / profile.density
        val thickness = 2f
        val offset = (dt * speed) % spacing

        var y = offset
        while (y < size.height) {
            drawLine(
                color = scanlineColor,
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = thickness
            )
            y += spacing
        }
    }
}
