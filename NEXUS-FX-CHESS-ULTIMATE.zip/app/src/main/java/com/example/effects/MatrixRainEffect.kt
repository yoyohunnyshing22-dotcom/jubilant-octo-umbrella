package com.example.effects

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.IntSize
import com.example.data.model.Profile
import kotlin.random.Random

/** Frame-driven Matrix rain renderer with persistent drops and real frame delta. */
@Composable
fun MatrixRainEffect(profile: Profile) {
    val drops = remember { mutableStateListOf<Drop>() }
    var viewport by remember { mutableStateOf(IntSize.Zero) }
    var frameTick by remember { mutableStateOf(0L) }

    val dropSpeed = (profile.speed.coerceIn(0.1f, 4f) * 500f)
    val density = profile.density.coerceIn(0.25f, 3f)

    LaunchedEffect(viewport, profile.speed, profile.density) {
        if (viewport.width <= 0 || viewport.height <= 0) return@LaunchedEffect

        val width = viewport.width.toFloat()
        val height = viewport.height.toFloat()
        val columns = (width / 34f * density).toInt().coerceIn(8, 90)

        drops.clear()
        repeat(columns) {
            drops += Drop(
                x = Random.nextFloat() * width,
                y = Random.nextFloat() * height,
                speed = Random.nextFloat() * dropSpeed * 0.7f + dropSpeed * 0.55f,
                length = Random.nextInt(7, 18)
            )
        }

        var lastFrame = 0L
        while (true) {
            withFrameNanos { now ->
                if (lastFrame != 0L) {
                    val dt = ((now - lastFrame) / 1_000_000_000f).coerceAtMost(0.05f)
                    drops.forEach { drop ->
                        drop.y += drop.speed * dt
                        if (drop.y - drop.length * 28f > height) {
                            drop.y = -Random.nextFloat() * height * 0.25f
                            drop.x = Random.nextFloat() * width
                            drop.speed = Random.nextFloat() * dropSpeed * 0.7f + dropSpeed * 0.55f
                        }
                    }
                }
                lastFrame = now
                frameTick = now
            }
        }
    }

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .onSizeChanged { newSize -> viewport = newSize }
    ) {
        // Read frameTick so Compose invalidates the Canvas every animation frame.
        frameTick
        val color = profile.primaryColor
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 28f
            typeface = android.graphics.Typeface.MONOSPACE
            textAlign = android.graphics.Paint.Align.CENTER
        }

        drawIntoCanvas { canvas ->
            drops.forEach { drop ->
                for (i in 0 until drop.length) {
                    val y = drop.y - i * 28f
                    if (y !in 0f..size.height) continue

                    val fade = 1f - (i.toFloat() / drop.length)
                    val alpha = (255f * profile.opacity.coerceIn(0f, 1f) * fade)
                        .toInt().coerceIn(0, 255)
                    paint.color = android.graphics.Color.argb(
                        alpha,
                        ((color shr 16) and 0xFF).toInt(),
                        ((color shr 8) and 0xFF).toInt(),
                        (color and 0xFF).toInt()
                    )

                    if (Random.nextFloat() > 0.92f) {
                        drop.chars[i] = randomChar()
                    }
                    canvas.nativeCanvas.drawText(
                        drop.chars[i].toString(),
                        drop.x,
                        y,
                        paint
                    )
                }
            }
        }
    }
}

private fun randomChar(): Char = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ<>[]{}*+-=#$%&@".random()

private class Drop(
    var x: Float,
    var y: Float,
    var speed: Float,
    val length: Int
) {
    val chars = CharArray(length) { randomChar() }
}
