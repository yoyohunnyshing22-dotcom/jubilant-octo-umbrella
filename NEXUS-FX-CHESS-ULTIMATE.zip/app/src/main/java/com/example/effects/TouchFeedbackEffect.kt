package com.example.effects

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import android.media.AudioManager
import android.media.ToneGenerator
import com.example.data.model.Profile
import com.example.service.NexusAccessibilityService
import kotlinx.coroutines.launch

@Composable
fun TouchFeedbackEffect(profile: Profile) {
    val touchEvent by NexusAccessibilityService.touchEvents.collectAsState()
    val activeRipples = remember { mutableStateListOf<RippleData>() }

    LaunchedEffect(touchEvent) {
        touchEvent?.let { event ->
            val ripple = RippleData(event.x, event.y)
            activeRipples.add(ripple)
            
            // Play a synthetic sound
            try {
                val toneType = when(profile.clickSound) {
                    "Cyber Click" -> ToneGenerator.TONE_PROP_BEEP
                    "Mechanical" -> ToneGenerator.TONE_PROP_BEEP2
                    "Soft" -> ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE
                    else -> ToneGenerator.TONE_PROP_BEEP
                }
                val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                tone.startTone(toneType, 50)
                // We'd ideally release it after delay, but tone generator auto stops after duration
            } catch (e: Exception) {
                // Ignore audio errors
            }

            launch {
                ripple.radius.animateTo(
                    targetValue = 200f,
                    animationSpec = tween(durationMillis = 400)
                )
                activeRipples.remove(ripple)
            }
            launch {
                ripple.alpha.animateTo(
                    targetValue = 0f,
                    animationSpec = tween(durationMillis = 400)
                )
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val baseColor = Color(profile.primaryColor)
        
        activeRipples.forEach { ripple ->
            val currentAlpha = ripple.alpha.value * profile.opacity
            drawCircle(
                color = baseColor.copy(alpha = currentAlpha),
                radius = ripple.radius.value,
                center = Offset(ripple.x, ripple.y),
                style = Stroke(width = 4f)
            )
        }
    }
}

class RippleData(val x: Float, val y: Float) {
    val radius = Animatable(0f)
    val alpha = Animatable(1f)
}
