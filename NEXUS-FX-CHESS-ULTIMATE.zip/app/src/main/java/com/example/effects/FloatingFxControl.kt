package com.example.effects

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SettingsRepository
import com.example.service.OverlayService
import kotlinx.coroutines.launch
import android.content.Intent
import androidx.compose.ui.platform.LocalContext

/** Premium compact controller: FX toggle + Chess. Tap Chess = overlay; long press = open inside NEXUS app. */
@Composable
fun FloatingFxControl(settings: SettingsRepository) {
    val enabled by settings.isGlobalFxEnabled.collectAsState(initial = true)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val cyan = Color(0xFF00E5FF)
    val bg = Color(0xEE061018)
    Row(
        modifier = Modifier.shadow(18.dp, RoundedCornerShape(18.dp)).background(bg, RoundedCornerShape(18.dp))
            .border(1.dp, cyan.copy(alpha = .72f), RoundedCornerShape(18.dp)).padding(horizontal = 5.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(Modifier.padding(horizontal=8.dp, vertical=6.dp).pointerInput(enabled){ detectTapGestures(onTap={scope.launch{settings.setGlobalFxEnabled(!enabled)}}) }, verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            Text("NEXUS", color=cyan, fontSize=11.sp)
            Text(if(enabled) "FX ON" else "FX OFF", color=Color.White, fontSize=11.sp)
            Text(if(enabled) "●" else "○", color=if(enabled) cyan else Color(0xFF667780), fontSize=12.sp)
        }
        Text("│", color=Color(0xFF34515A), fontSize=14.sp)
        Row(
            Modifier.padding(horizontal=9.dp, vertical=6.dp).pointerInput(Unit){
                detectTapGestures(
                    onTap={ context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_OPEN_CHESS)) },
                    onLongPress={ context.startActivity(Intent(context, com.example.MainActivity::class.java).apply { putExtra("OPEN_CHESS_PAGE", true); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP) }) }
                )
            }, verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.spacedBy(5.dp)
        ) { Text("♞", color=cyan, fontSize=16.sp); Text("CHESS", color=Color.White, fontSize=11.sp) }
    }
}
